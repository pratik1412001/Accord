$(document).ready(function(){
    $(".accordion").accordion();
    $('#image_slide').slick({
      // autoplay: true,
        infinite: true,
        dots:true,
        slidesToShow: 1,
        slidesToScroll: 1,
      
      });
});

